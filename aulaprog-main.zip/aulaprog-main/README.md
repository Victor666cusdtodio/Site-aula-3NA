# saudemetal
Esse projeto tem como finalidade analisar como está a saúde emocinal dos estudantes.
